/* global QUnit */

sap.ui.require(["cicdpocui/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});

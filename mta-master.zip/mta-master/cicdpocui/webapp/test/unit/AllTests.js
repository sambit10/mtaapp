sap.ui.define([
	"cicdpocui/test/unit/controller/Test.controller"
], function () {
	"use strict";
});
